const connectWalletBtn = document.getElementById("connectWallet");
const walletAddress = document.getElementById("walletAddress");
const priceList = document.getElementById("priceList");

// Replace with your actual backend URL once deployed
const BACKEND_URL = "https://crypto-backend-gzw3.onrender.com";

connectWalletBtn.addEventListener("click", async () => {
  if (window.ethereum) {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      const address = accounts[0];
      walletAddress.textContent = "Wallet: " + address;

      // Send address to backend
      await fetch(`${BACKEND_URL}/log-wallet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address }),
      });

      console.log("Wallet address logged:", address);
    } catch (error) {
      console.error("Wallet connection error:", error);
    }
  } else {
    alert("Please install MetaMask.");
  }
})